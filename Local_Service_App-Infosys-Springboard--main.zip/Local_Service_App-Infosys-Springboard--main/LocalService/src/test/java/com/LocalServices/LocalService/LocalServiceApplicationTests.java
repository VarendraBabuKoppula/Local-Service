package com.LocalServices.LocalService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.LocalServices.LocalService.model;

public enum PaymentMethod {
    CARD,
    UPI,
    NET_BANKING,
    CASH
}

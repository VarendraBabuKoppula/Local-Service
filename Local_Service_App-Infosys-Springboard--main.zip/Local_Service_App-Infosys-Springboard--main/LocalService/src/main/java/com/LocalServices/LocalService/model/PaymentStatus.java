package com.LocalServices.LocalService.model;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED
}
